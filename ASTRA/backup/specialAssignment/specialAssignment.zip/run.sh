#!/bin/bash


nohup python3 specialAssignment.py 1 > output.out 2 > output.err &