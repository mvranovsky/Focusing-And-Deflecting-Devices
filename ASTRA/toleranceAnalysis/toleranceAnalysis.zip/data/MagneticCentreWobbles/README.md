# Magnetic centre wobbles

These data come from analyzing wobbles of magnetic centre in X and Y directions. There are 3 separate runs, one with good beam meaning initial emittance 1 pi mm mrad, and bad beam with initial emittance 9 pi mm mrad. Last run is also with good beam, but in this case the integrated gradient of each quadrupole stays the same. This was done by choosing wobbles in X and Y be modelled only by cosine function with frequency being m2pi/L where m is a natural number between 1 and 5. 
